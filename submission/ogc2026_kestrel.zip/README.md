# OGC 2026 submission — Kestrel

`myalgorithm.py` is the submission entry point and exposes the required:

```python
algorithm(prob_info, timelimit=60)
```

## Method

Kestrel is an anytime spatio-temporal packing heuristic:

1. It immediately constructs a fit-aware serial solution and validates it with
   the official checker. This is the always-feasible incumbent.
2. It builds several fast schedules using all-layer rectangle envelopes,
   urgency rules selected from the instance regime, exact marginal workload
   imbalance, and exact bay-preference regret.
3. For instances where it is computationally worthwhile, it replaces rectangle
   packing with true irregular-polygon packing.
4. It improves the incumbent with exact-objective single-block reinsertions and
   time-window/bay ruin-and-recreate neighborhoods.
5. Every promoted incumbent is accepted only after
   `utils.check_feasibility()` passes.

The core safety invariant is stronger than the formal collision rule: any two
blocks whose residence intervals overlap have disjoint interiors for the unions
of all their layers. Consequently, both the static layer constraints and every
vertical ENTRY/EXIT crane sweep are feasible without post-hoc repair. Same-day
EXIT-before-ENTRY reuse remains fully available.

## Why this differs from the baseline

The supplied baseline repeatedly discovers crane-order violations after
construction and can push repeat offenders into far-future empty-bay windows.
Kestrel makes crane safety constructive, uses actual polygon geometry rather
than AABBs in its strong decoder, calculates exact `Z2`/`Z3` assignment deltas,
and spends remaining time on coordinated improvement.

The design follows established spatial-scheduling ideas—priority-rule decoding,
bottom-left/contact placement, and sequence search—while adapting them to the
competition's layered crane rule. Relevant literature includes Kwon and Lee's
shipbuilding spatial-scheduling work (Computers & Industrial Engineering 89,
2015), Ge and Wang's irregular-block method (Computers & Industrial Engineering
152, 2021), and Shang et al.'s best-contact plus genetic search method
(Mathematical Problems in Engineering, 2017).

## Local validation

- Python syntax compilation: passed.
- Official `utils.check_feasibility`: passed on all 40 supplied training
  instances at a deliberately short 2.5-second limit.
- Representative improvements:
  - `prob_1`: prior baseline 795,089 with 26 tardy days after 56.5 seconds;
    Kestrel 8,847 with zero tardy days.
  - `prob_25`: prior baseline 823,887 with 1,192 tardy days after 221 seconds;
    Kestrel 351,265 with 472 tardy days in a 60-second run.
- Submission uses only Python's standard library and Shapely, both present in
  the published OGC environment.

The server supplies/overwrites `utils.py`; it is intentionally not included.
